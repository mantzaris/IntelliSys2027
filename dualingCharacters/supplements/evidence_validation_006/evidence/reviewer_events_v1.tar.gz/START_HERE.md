# Independent fixed-event review

Open REVIEW.html offline, read RUBRIC.md and the disjoint CALIBRATION.md, and complete only your assigned rater CSV. Keep all72 rows. EPISODES.html supplies optional full context. Full-episode forms from earlier packets are not additionally required. Do not exchange labels before independent completion. Preserve your completed form and provenance; adjudication is separate. No AI judgments or condition key is included.
